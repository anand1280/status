<?php
		// $link = mysqli_connect("localhost", "amgb3mkljcjm", "Asha@12h60");
		$link = mysqli_connect("localhost", "root", "anand1280");
		mysqli_select_db($link, "status");  
		mysqli_query($link, "SET CHARACTER SET utf8");
		?>
		
