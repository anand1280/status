<?php
				include "includes/header.php";
				?>

				<h1>Customers</h1>
				<p>This table includes <?php echo counting("user_infotbl", "id");?> Customers.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Number</th>
					<th>Customer Name</th>
					<th>Customer Email</th>
					<!--<th>Password</th>-->
					<th>Customer Mobile Number</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$users = getAll("user_infotbl");
				if($users) foreach ($users as $userss):
					?>
					<tr>
						<td><?php echo $userss['uid']?></td>
						<td><?php echo $userss['uname']?></td>
						<td><?php echo $userss['uemail']?></td>
						<td><?php echo $userss['umobile']?></td>
						<td><?php if($userss['role']!=1){ ?><a href="save.php?act=delete&id=<?php echo $userss['uid']?>&cat=user_infotbl" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a><?php } ?></td>
						</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				