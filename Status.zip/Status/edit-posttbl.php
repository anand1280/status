<?php
				include "includes/header.php";
				$data=[];

				$act = $_GET['act'];
				if($act == "edit"){
					$id = $_GET['id'];
					$posttbl = getById("posttbl", $id);
				}
				?>
			
	<style type="text/css">
		#state-select{
			display: none;
		}
	</style>

				<form method="post" action="save.php" enctype='multipart/form-data'>
					<fieldset>
						<legend class="hidden-first">Add New Posttbl</legend>
						<input name="cat" type="hidden" value="posttbl">
						<input name="id" type="hidden" value="<?=$id?>">
						<input name="act" type="hidden" value="<?=$act?>">

						<label>Select-Language</label>
							<?php
							$query = "SELECT * FROM languagetbl ";
							$result = qSELECT($query);
							?>
							<select name="languageid"  class="form-control" id="country-select" required>
							<option disabled selected>Please Select Languange</option>
							<?php
							foreach ($result as $row){
								?>
									<option value="<?=$row['languageid']?>" ><?php echo $row['languagename']; ?></option>
								<?php
							}
							?>
							</select><br>
							<label>Please Select Category</label>
							
							<select id="state-select" name="categoryid" class="form-control" required>
							
							</select><br>
							<br>
		
	

<script type="text/javascript">
		function getStatesSelectList(){
			var country_select = document.getElementById("country-select");
			
			
			var country_id = country_select.options[country_select.selectedIndex].value;
			console.log('CountryId : ' + country_id);
 
			var xhr = new XMLHttpRequest();
			var url = 'states.php?country_id=' + country_id;
			// open function
			xhr.open('GET', url, true);
			xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			
			// check response is ready with response states = 4
			xhr.onreadystatechange = function(){
				if(xhr.readyState == 4 && xhr.status == 200){
					var text = xhr.responseText;
					//console.log('response from states.php : ' + xhr.responseText);
					var state_select = document.getElementById("state-select");
					state_select.innerHTML = text;
					state_select.style.display='inline';
					
				}
			}
 
			xhr.send();
		}
 
	
 
		var country_select = document.getElementById("country-select");
		country_select.addEventListener("change", getStatesSelectList);
 
	</script>

							

							<label>Tumbnail Image</label>
							<input class="form-control" type="file" name="thumb" value="<?=$posttbl['thumb']?>" required/><br>
							
							<label>Title</label>
							<input class="form-control" type="text" name="title" value="<?=$posttbl['title']?>" required/><br>
							
							<label>Browse Video/Image</label>
							<input class="form-control" type="file" name="postpath" value="<?=$posttbl['postpath']?>" required/><br>
							
							<label>No of like</label>
							<input class="form-control" type="text" name="no_of_like" value="<?=$posttbl['no_of_like']?>" required/><br>
							
							<label>No of share</label>
							<input class="form-control" type="text" name="no_of_share" value="<?=$posttbl['no_of_share']?>" required/><br>
							
							<label>No of download</label>
							<input class="form-control" type="text" name="no_of_download" value="<?=$posttbl['no_of_download']?>"required /><br>
							
							<label>No of view</label>
							<input class="form-control" type="text" name="no_of_view" value="<?=$posttbl['no_of_view']?>" required/><br>
							
					<input type="submit" value=" Save " class="btn btn-success">
					</form>


					<?php include "includes/footer.php";?>
				