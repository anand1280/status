<?php
				include "includes/header.php";
				$data=[];

				$act = $_GET['act'];
				if($act == "edit"){
					$id = $_GET['id'];
					$categorytbl = getById("categorytbl", $id);
				}
				?>

				<form method="post" action="save.php" enctype='multipart/form-data'>
					<fieldset>
						<legend class="hidden-first">Add New Category</legend>
						<input name="cat" type="hidden" value="categorytbl">
						<input name="id" type="hidden" value="<?=$id?>">
						<input name="act" type="hidden" value="<?=$act?>">
				
							<label>Select-Language</label>
							<?php
							$query = "SELECT * FROM languagetbl ";
							$result = qSELECT($query);
							?>
							<select name="languageid" class="form-control" required="">
							<?php
							foreach ($result as $row){
								?>
									<option value="<?=$row['languageid']?>" ><?php echo $row['languagename']; ?></option>
								<?php
							}
							?>
							</select><br>
							
							<label>Category-Name</label>
							<input class="form-control" type="text" name="categoryname" value="<?=$categorytbl['categoryname']?>" required=""/><br>
							<br>


							<label>Category-Image</label>
							<input class="form-control" type="file" name="categoryimg" value="<?=$categorytbl['categoryimg']?>" required=""/><br>
							<br>
					<input type="submit" value=" Save " class="btn btn-success">
					</form>
					<?php include "includes/footer.php";?>
				