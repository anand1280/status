<?php

include('../Database/db_connect.php');

		if(isset($_GET['categoryname']))
		{
		    $catname = $_GET['categoryname'];
		}
			$status=200;
			$status_message="Item Found";	
			header("Access-Control-Allow-Origin: *");
			header("Content-Type: application/json; charset=UTF-8");
			header("Access-Control-Allow-Methods: POST");
			header("Access-Control-Max-Age: 3600");
			header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
			header("Content-Type:application/json");
			header("HTTP/1.1 ".$status);	

			$commonurl="./";
			$response['status']=$status;
			$response['status_message']=$status_message;
			$response['common_url']=$commonurl;

			$response['all']= getAllCat($conn,$catname);	
			$json_response = json_encode($response);
			echo $json_response;
	

        function getAllCat($conn,$catname) {	
			$dataAllCategory = array();
			$sql = "SELECT * FROM posttbl as p,languagetbl as l,categorytbl as c where p.languageid=l.languageid AND p.categoryid=c.categoryid AND c.categoryname='".$catname."' ORDER BY p.postid DESC";
			$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
			while( $rows = mysqli_fetch_assoc($resultset) ) {
				$dataAllCategory[] = $rows;	
			}
			return $dataAllCategory;
	}
?>