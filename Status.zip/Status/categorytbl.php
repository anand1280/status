<?php
				include "includes/header.php";
				?>

				<a class="btn btn-primary" href="edit-categorytbl.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Category</a>

				<h1>Category</h1>
				<p>This table includes <?php echo counting("categorytbl", "id");?> Category.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Category Number</th>
					<th>Language</th>
					<th>Category Name</th>
					<th>Category Image</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$i=1;
				$categorytbl = getPost();
				if($categorytbl) foreach ($categorytbl as $categorytbls):
					?>
					<tr>
						<!--<td><?php echo $categorytbls['categoryid']?></td>-->
						<td><?php echo $i; $i++; ?></td>
						<td><?php echo $categorytbls['languagename']?></td>
						<td><?php echo $categorytbls['categoryname']?></td>
						<td><img src="<?php echo $categorytbls['category_img']?>" height=150 width=150></td>
						<td><a href="save.php?act=delete&id=<?php echo $categorytbls['categoryid'];?>&cat=categorytbl" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
					</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				
