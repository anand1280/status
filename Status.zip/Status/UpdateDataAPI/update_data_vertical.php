<?php

include('../Database/db_connect.php');

function msg($status_message){

    $status=200;
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    header("Content-Type:application/json");
    header("HTTP/1.1 ".$status_message);	

    $response['status']=$status;
    $response['status_message']=$status_message;
    	
    $json_response = json_encode($response);
    echo $json_response;
}
function nomsg($status_message){

    $status=401;
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    header("Content-Type:application/json");
    header("HTTP/1.1 ".$status_message);    

    $response['status']=$status;
    $response['status_message']=$status_message;
        
    $json_response = json_encode($response);
    echo $json_response;
}
// Plus Like 
if(isset($_GET['likeplus']))
{
    $postdata=$_GET['likeplus'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM posttbl_vertical WHERE postid=$postdata";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	
	while( $rows = mysqli_fetch_assoc($resultset) ) {
        $getlike = $rows['no_of_like'];
    }
    
    if(isset($getlike) && isset($postdata))
    {
        $sql = "UPDATE posttbl_vertical SET no_of_like=$getlike+1 WHERE postid=$postdata";
    
        if ($conn->query($sql) === TRUE) {
            msg("Like Plus Successfully");
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else{
        nomsg("Something is wrong");
    }
    
    $conn->close();
    
    
}

// Minus Like
if(isset($_GET['likeminus']))
{
    $postdata=$_GET['likeminus'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM posttbl_vertical WHERE postid=$postdata";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	
	while( $rows = mysqli_fetch_assoc($resultset) ) {
        $getlike = $rows['no_of_like'];
    }
    
    if(isset($getlike) && isset($postdata))
    {
        $sql = "UPDATE posttbl_vertical SET no_of_like=$getlike-1 WHERE postid=$postdata";
    
        if ($conn->query($sql) === TRUE) {
            msg("Like Minus Successfully");
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else{
        nomsg("Something is wrong");
    }
    
    $conn->close();
}

// Plus Share
if(isset($_GET['share']))
{
    $postdata=$_GET['share'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM posttbl_vertical WHERE postid=$postdata";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	
	while( $rows = mysqli_fetch_assoc($resultset) ) {
        $getlike = $rows['no_of_share'];
    }
    
    if(isset($getlike) && isset($postdata))
    {
        $sql = "UPDATE posttbl_vertical SET no_of_share=$getlike+1 WHERE postid=$postdata";
    
        if ($conn->query($sql) === TRUE) {
            msg("Share Plus Successfully");
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else{
        nomsg("Something is wrong");
    }
    
    $conn->close();
    
    
}

// Plus Download
if(isset($_GET['download']))
{
    $postdata=$_GET['download'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM posttbl_vertical WHERE postid=$postdata";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	
	while( $rows = mysqli_fetch_assoc($resultset) ) {
        $getlike = $rows['no_of_download'];
    }
    
    if(isset($getlike) && isset($postdata))
    {
        $sql = "UPDATE posttbl_vertical SET no_of_download=$getlike+1 WHERE postid=$postdata";
    
        if ($conn->query($sql) === TRUE) {
            msg("Download Plus Successfully");
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else{
        nomsg("Something is wrong");
    }
    
    $conn->close();
        
}

// Plus View
if(isset($_GET['view']))
{
    $postdata=$_GET['view'];
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM posttbl_vertical WHERE postid=$postdata";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	
	while( $rows = mysqli_fetch_assoc($resultset) ) {
        $getlike = $rows['no_of_view'];
    }
    
    if(isset($getlike) && isset($postdata))
    {
        $sql = "UPDATE posttbl_vertical SET no_of_view=$getlike+1 WHERE postid=$postdata";
    
        if ($conn->query($sql) === TRUE) {
            msg("View Plus Successfully");
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }else{
        nomsg("Something is wrong");
    }
    
    $conn->close();
    
    
}




?>
