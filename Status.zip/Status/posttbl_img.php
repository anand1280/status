<?php
				include "includes/header.php";
				?>

				<a class="btn btn-primary" href="edit-posttbl_img.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Post</a>

				<h1>Post</h1>
				<p>This table includes <?php echo counting("posttbl_img", "id");?> posts.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Post No.</th>
					<th>Category</th>
					<th>Language</th>
					<th>Thumbnail Image</th>
					<th>Title</th>
					<!--<th>Post-Path</th>-->
					<th>No. of Like</th>
					<th>No. of Share</th>
					<th>No. of Download</th>
					<th>No. of View</th>
					<th>Post-Date</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$i=1;
				$posttbl = getPost2();
				if($posttbl) foreach ($posttbl as $posttbls):
					?>
					<tr>
						<!--<td><?php echo $posttbls['postid']?></td>-->
						<td><?php echo $i; $i++; ?></td>
						<td><?php echo $posttbls['categoryname']?></td>
						<td><?php echo $posttbls['languagename']?></td>
						<td><img src="<?php echo $posttbls['thumbnail_img']?>" height=150 width=150></td>
						<td><?php echo $posttbls['title']?></td>
						<!--<td><?php echo $posttbls['postpath']?></td>-->
						<td><?php echo $posttbls['no_of_like']?></td>
						<td><?php echo $posttbls['no_of_share']?></td>
						<td><?php echo $posttbls['no_of_download']?></td>
						<td><?php echo $posttbls['no_of_view']?></td>
						<td><?php echo $posttbls['post_date']?></td>
						<td><a href="save.php?act=delete&id=<?php echo $posttbls['postid']?>&cat=posttbl_img" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				