<?php

include('../Database/db_connect.php');

	getItems($conn);	
	
	function getpostdata($getobj,$conn){
		$datapost1 = array();
			$sql1="SELECT * from posttbl";
            $result = mysqli_query($conn, $sql1) or die("database error:". mysqli_error($conn));
            $row1 = mysqli_num_rows($result); 
		
		$sql2 = "SELECT * FROM posttbl as p,languagetbl as l,categorytbl c  where l.languageid = c.languageid AND p.categoryid=c.categoryid AND  p.categoryid =".$getobj." ORDER BY RAND() LIMIT $row1";
		
			
		$resultset2 = mysqli_query($conn, $sql2) or die("database error:". mysqli_error($conn));
		while( $rows2 = mysqli_fetch_assoc($resultset2) ) {
			$datapost1[]=$rows2;
		}
		return $datapost1;
	}
	 

	function getSingleObj($getobj,$conn){
		$datapost = array();
		$sql1 = "SELECT * FROM categorytbl c,languagetbl l where l.languageid = c.languageid and l.languageid=".$getobj;
	
		$resultset1 = mysqli_query($conn, $sql1) or die("database error:". mysqli_error($conn));
		while( $rows1 = mysqli_fetch_assoc($resultset1) ) {
			$rows1['Post_data']=getpostdata($rows1['categoryid'],$conn);
			$datapost[]=$rows1;
		}
		return $datapost;
	}
			
	function getItems($conn) {	
		$data = array();
		$sql = "SELECT * FROM languagetbl";
		$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
		while( $rows = mysqli_fetch_assoc($resultset) ) {
			$rows['Category_data']=getSingleObj($rows['languageid'],$conn);
			$data[] = $rows;	
		}
		
			$status=200;
			$status_message="Item Found";	
			header("Access-Control-Allow-Origin: *");
			header("Content-Type: application/json; charset=UTF-8");
			header("Access-Control-Allow-Methods: POST");
			header("Access-Control-Max-Age: 3600");
			header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
			header("Content-Type:application/json");
			header("HTTP/1.1 ".$status);	

			$commonurl="";
			$response['status']=$status;
			$response['status_message']=$status_message;
			$response['common_url']=$commonurl;
			
			$response['data']=$data;
                        $response['all'] = getAllCat($conn);	
			$json_response = json_encode($response);
			echo $json_response;
	}

        function getAllCat($conn) {	
			$sql1="SELECT * from posttbl";
            $result = mysqli_query($conn, $sql1) or die("database error:". mysqli_error($conn));
            $row1 = mysqli_num_rows($result); 
            
      
                

			$dataAllCategory = array();
			$sql = "SELECT * FROM posttbl as p,languagetbl as l,categorytbl as c where p.languageid=l.languageid AND p.categoryid=c.categoryid  ORDER BY RAND() LIMIT $row1";
			
			$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
			while( $rows = mysqli_fetch_assoc($resultset) ) {
				$dataAllCategory[] = $rows;	
			}
			return $dataAllCategory;
	}
?>
