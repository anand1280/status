<?php
include('../Database/db_connect.php');
if(isset($_GET['email'])){
    if($_GET['email']!=null){

        $uemail=$_GET['email'];
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT * FROM user_infotbl WHERE uemail='$uemail'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $set="valid user";
            }
            if(isset($set)){
                ?>
                <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>

<h2>Set Your Password </h2>


<div class="container">
  <form action="http://www.appforstatus.com/final_backup-master/API-MyStatus-Application/Final-API/Login_Module/setpassword.php?email=<?php echo $uemail; ?>" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">New Password</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="npassword" placeholder="New password">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Re-Enter New Password</label>
      </div>
      <div class="col-75">
        <input type="text" id="lname" name="rnpassword" placeholder="Re-enter new password">
      </div>
    </div>
    
    <div class="row">
      <input type="submit" name="change"  value="Submit">
    </div>
  </form>
</div>

</body>
</html>

                <?php
            }
        }
    }
}
if(isset($_POST['change'])){
    if($_POST['npassword']!=null && isset($_POST['npassword'])){
        if($_POST['rnpassword']!=null && isset($_POST['rnpassword'])){
            $npass=$_POST['npassword'];
            $rnpass=$_POST['rnpassword'];
            if($npass==$rnpass){
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                if(isset($_GET['email'])){
                    if($_GET['email']!=null){
                
                        $uemail=$_GET['email'];
                    }
                }

                $sql = "UPDATE user_infotbl SET upassword='md5($rnpass)' WHERE uemail='$uemail'";
                
                if ($conn->query($sql) === TRUE) {
                   header( "Location: https://play.google.com/store/apps/details?id=com.videoapp.sevenbit" );

                } else {
                    ?>
                    <script>alert("Error while setting Password");</script>
                    <?php
                }
                
                $conn->close();
            }else{
                ?>
                    <script>alert("Please enter same password");</script>
                    <?php
            }
        }else{
            ?>
            <script>alert("Something went wrong");</script>
            <?php
        }
    }else{
        ?>
        <script>alert("Something went wrong");</script>
        <?php
    }
}else{
    ?>
    <script>alert("Something went wrong");</script>
    <?php
}

?>