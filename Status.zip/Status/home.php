<?php
		include "includes/header.php";
		?>
		
		<span><h1>Welcome to My Status</h1>  </span>
		
		<table class="table table-striped">
		<tr>
		<th class="not">Table</th>
		<th class="not">Entries</th>
		</tr>
				<tr>
					<td><a href="customertbl.php">Customers</a></td>
					<td><?=counting("user_infotbl", "id")?></td>
				</tr>	
				<tr>
					<td><a href="categorytbl.php">Category</a></td>
					<td><?=counting("categorytbl", "id")?></td>
				</tr>
				
				
				<tr>
					<td><a href="languagetbl.php">Language</a></td>
					<td><?=counting("languagetbl", "id")?></td>
				</tr>
				
				<tr>
					<td><a href="posttbl.php">Horizontal Videos</a></td>
					<td><?=counting("posttbl", "id")?></td>
				</tr>
				<tr>
					<td><a href="posttbl_vertical.php">Vertical Videos</a></td>
					<td><?=counting("posttbl_vertical", "id")?></td>
				</tr>
				
				
				<tr>
					<td><a href="posttbl_img.php">Images</a></td>
					<td><?=counting("posttbl_img", "id")?></td>
				</tr>
				
				
				<tr>
					<td><a href="posttbl_img.php">User Upload</a></td>
					<td><?=counting("posttbl_user", "id")?></td>
				</tr>
				
				<tr>
					<td><a href="users.php">Users</a></td>
					<td><?=counting("users", "id")?></td>
				</tr>
				</table>
			<?php include "includes/footer.php";?>
			