<?php
include('./Database/db_connect.php');
include('./getID3-master/getid3/getid3.php');

function basic_fun(){
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	header("Content-Type:application/json");
}
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		$getID3 = new getID3;
		if(isset($_FILES['file']) && isset($_FILES['thumbnail']) && isset($_GET['email'])) {
			if ($_FILES["file"]["size"] <= 15000000) {
				$target_dir = "./";
				$target_file = $target_dir . $_FILES["file"]["name"];
				$FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				$file = $getID3->analyze($_FILES["file"]["tmp_name"]);

				if($FileType == "jpg" || $FileType == "png" || $FileType == "jpeg" || $FileType == "mp4") {
					//Get user email address
					$email=$_GET['email'];
					
					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$sql = "SELECT * FROM user_infotbl WHERE uemail='$email'";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							$userid=$row["uid"];
							$username=$row["uname"];
						}
					}

					if($FileType == "jpg" || $FileType == "png" || $FileType == "jpeg" ){

						if(isset($userid) && isset($username)){
							// Set Directory
							$targetDir1 = "./uploads/Images/";
							$thumb = mysqli_real_escape_string($conn, $_FILES['file']['name']);
							$fileName1 = basename($thumb);
							
							$targetFilePath1 = $targetDir1 ."u".rand(1,10000). $username.$fileName1;
							$fileType1 = pathinfo($targetFilePath1, PATHINFO_EXTENSION);

							if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath1)){
								$filename=$targetFilePath1;
								if(isset($userid) && isset($username)){
									$username1=strtolower("u".$username);
								
									// Insert image record
									$sql = "INSERT INTO posttbl_img (categoryid,languageid,uid,thumbnail_img,title,postpath,no_of_like,no_of_share,no_of_download,no_of_view) VALUES (10,3,'$userid','$filename','$username1','$filename',1,1,1,1)";
									
									if($conn->query($sql)){		
										basic_fun();
										$status=200;
										$status_message="Image uploaded";
										header("HTTP/1.1 ".$status);	
										$response['status']=$status;
										$response['status_message']=$status_message;
										$json_response = json_encode($response);
										echo $json_response;	
									}else{
										// Image is not uploaded
										basic_fun();
										$status=200;
										$status_message="Image is not uploaded";
										header("HTTP/1.1 ".$status);	
										$response['status']=$status;
										$response['status_message']=$status_message;
										$json_response = json_encode($response);
										echo $json_response;
									}
								}else{
									basic_fun();
									$status=200;
									$status_message="User is not valid";
									header("HTTP/1.1 ".$status);	
									$response['status']=$status;
									$response['status_message']=$status_message;
									$json_response = json_encode($response);
									echo $json_response;
								}
							}else{
								basic_fun();
								$status=200;
								$status_message="File is not Uploaded";
								header("HTTP/1.1 ".$status);	
								$response['status']=$status;
								$response['status_message']=$status_message;
								$json_response = json_encode($response);
								echo $json_response;
							}
						}else{
							basic_fun();
							$status=200;
							$status_message="User is not Logged in";
							header("HTTP/1.1 ".$status);	
							$response['status']=$status;
							$response['status_message']=$status_message;
							$json_response = json_encode($response);
							echo $json_response;
						}
					}elseif($FileType == "mp4"){
					    if($file['video']['resolution_x'] > $file['video']['resolution_y'])
					    {
					        // x=width y=height

					        if($file['video']['resolution_y'] > 170)
					        {
					        	//Vertical video
							        if(isset($userid) && isset($username)){
										//$targetDir1 = "./uploads/Images/";
										$targetDir2 = "./uploads/Vertical_Videos/";
										$thumb = mysqli_real_escape_string($conn, $_FILES['file']['name']);
										$fileName2 = basename($thumb);
										
										$targetFilePath2 = $targetDir2 ."u".rand(1,10000). $username.$fileName2;
										$fileType2 = pathinfo($targetFilePath2, PATHINFO_EXTENSION);
										
										
										$targetDirt = "./uploads/Vertical_Videos/";
										$thumbt = mysqli_real_escape_string($conn, $_FILES['thumbnail']['name']);
										$fileNamet = basename($thumbt);
										
										$targetFilePatht = $targetDirt ."u".rand(1,10000). $username.$fileNamet;
										$fileTypet = pathinfo($targetFilePatht, PATHINFO_EXTENSION);
										
							            move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $targetFilePatht);
										// Upload file to server
										if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath2)){
											if(isset($userid) && isset($username)){
												$username1=strtolower("u".$username);
												$sql = "INSERT INTO posttbl_vertical (categoryid,languageid,uid,thumbnail_img,title,postpath,no_of_like,no_of_share,no_of_download,no_of_view) VALUES (41,12,'$userid','$targetFilePatht','$username1','$targetFilePath2',1,1,1,1)";
												if($conn->query($sql)){		
													basic_fun();
													$status=200;
													$status_message="video uploaded ";	
													header("HTTP/1.1 ".$status);	
													$response['status']=$status;
													$response['status_message']=$status_message;
													$json_response = json_encode($response);
													echo $json_response;
													$conn->close();
												}else{
													basic_fun();
													$status=200;
													$status_message="Something went wrong";	
													header("HTTP/1.1 ".$status);	
													$response['status']=$status;
													$response['status_message']=$status_message;
													$json_response = json_encode($response);
													echo $json_response;
												}
											}else{
												basic_fun();
												$status=200;
												$status_message="Something went wrong";	
												header("HTTP/1.1 ".$status);	
												$response['status']=$status;
												$response['status_message']=$status_message;
												$json_response = json_encode($response);
												echo $json_response;
											}
										}else{
											basic_fun();
											$status=200;
											$status_message="file is not uploaded";	
											header("HTTP/1.1 ".$status);	
											$response['status']=$status;
											$response['status_message']=$status_message;
											$json_response = json_encode($response);
											echo $json_response;
										}
			
									}else{
										basic_fun();
										$status=200;
										$status_message="Please resubmit your file";	
										header("HTTP/1.1 ".$status);	
										$response['status']=$status;
										$response['status_message']=$status_message;
										$json_response = json_encode($response);
										echo $json_response;
									}
								
					        }
					        else
					        {

					        if(isset($userid) && isset($username)){
								//$targetDir1 = "./uploads/Images/";
								$targetDir2 = "./uploads/Videos/";
								$thumb = mysqli_real_escape_string($conn, $_FILES['file']['name']);
								$fileName1 = basename($thumb);
								
								$targetFilePath1 = $targetDir1 ."u".rand(1,10000). $username.$fileName1;
								$fileType1 = pathinfo($targetFilePath1, PATHINFO_EXTENSION);
								
								
								$targetDirh = "./uploads/Videos/";
								$thumbh = mysqli_real_escape_string($conn, $_FILES['thumbnail']['name']);
								$fileNameh = basename($thumbh);
								
								$targetFilePathh = $targetDirh ."u".rand(1,10000). $username.$fileNameh;
								$fileTypeh = pathinfo($targetFilePathh, PATHINFO_EXTENSION);
								
					            move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $targetFilePathh);
					
					
								// Upload file to server
								if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath1)){
									if(isset($userid) && isset($username)){
										$username1=strtolower("u".$username);
										$sql = "INSERT INTO posttbl (categoryid,languageid,uid,thumbnail_img,title,postpath,no_of_like,no_of_share,no_of_download,no_of_view) VALUES (41,12,'$userid','$targetFilePathh','$username1','$targetFilePath1',1,1,1,1)";
										if($conn->query($sql)){		
											basic_fun();
											$status=200;
											$status_message="Video Uploaded";	
											header("HTTP/1.1 ".$status);	
											$response['status']=$status;
											$response['status_message']=$status_message;
											$json_response = json_encode($response);
											echo $json_response;
											$conn->close();
										}else{
											basic_fun();
											$status=200;
											$status_message="Something went wrong";	
											header("HTTP/1.1 ".$status);	
											$response['status']=$status;
											$response['status_message']=$status_message;
											$json_response = json_encode($response);
											echo $json_response;
										}
									}else{
										basic_fun();
										$status=200;
										$status_message="Something went wrong";	
										header("HTTP/1.1 ".$status);	
										$response['status']=$status;
										$response['status_message']=$status_message;
										$json_response = json_encode($response);
										echo $json_response;
									}
								}else{
									basic_fun();
									$status=200;
									$status_message="File is not Uploaded";	
									header("HTTP/1.1 ".$status);	
									$response['status']=$status;
									$response['status_message']=$status_message;
									$json_response = json_encode($response);
									echo $json_response;
								}
	
							}else{
								basic_fun();
								$status=200;
								$status_message="Please resubmit your file";	
								header("HTTP/1.1 ".$status);	
								$response['status']=$status;
								$response['status_message']=$status_message;
								$json_response = json_encode($response);
								echo $json_response;
							}
					        }
							

						}else{

							// Vertical Video
							if(isset($userid) && isset($username)){
								//$targetDir1 = "./uploads/Images/";
								$targetDir2 = "./uploads/Vertical_Videos/";
								$thumb = mysqli_real_escape_string($conn, $_FILES['file']['name']);
								$fileName2 = basename($thumb);
								
								$targetFilePath2 = $targetDir2 ."u".rand(1,10000). $username.$fileName2;
								$fileType2 = pathinfo($targetFilePath2, PATHINFO_EXTENSION);
								
								
								$targetDirt = "./uploads/Vertical_Videos/";
								$thumbt = mysqli_real_escape_string($conn, $_FILES['thumbnail']['name']);
								$fileNamet = basename($thumbt);
								
								$targetFilePatht = $targetDirt ."u".rand(1,10000). $username.$fileNamet;
								$fileTypet = pathinfo($targetFilePatht, PATHINFO_EXTENSION);
								
					            move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $targetFilePatht);
								// Upload file to server
								if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath2)){
									if(isset($userid) && isset($username)){
										$username1=strtolower("u".$username);
										$sql = "INSERT INTO posttbl_vertical (categoryid,languageid,uid,thumbnail_img,title,postpath,no_of_like,no_of_share,no_of_download,no_of_view) VALUES (41,12,'$userid','$targetFilePatht','$username1','$targetFilePath2',1,1,1,1)";
										if($conn->query($sql)){		
											basic_fun();
											$status=200;
											$status_message="video uploaded ";	
											header("HTTP/1.1 ".$status);	
											$response['status']=$status;
											$response['status_message']=$status_message;
											$json_response = json_encode($response);
											echo $json_response;
											$conn->close();
										}else{
											basic_fun();
											$status=200;
											$status_message="Something went wrong";	
											header("HTTP/1.1 ".$status);	
											$response['status']=$status;
											$response['status_message']=$status_message;
											$json_response = json_encode($response);
											echo $json_response;
										}
									}else{
										basic_fun();
										$status=200;
										$status_message="Something went wrong";	
										header("HTTP/1.1 ".$status);	
										$response['status']=$status;
										$response['status_message']=$status_message;
										$json_response = json_encode($response);
										echo $json_response;
									}
								}else{
									basic_fun();
									$status=200;
									$status_message="file is not uploaded";	
									header("HTTP/1.1 ".$status);	
									$response['status']=$status;
									$response['status_message']=$status_message;
									$json_response = json_encode($response);
									echo $json_response;
								}
	
							}else{
								basic_fun();
								$status=200;
								$status_message="Please resubmit your file";	
								header("HTTP/1.1 ".$status);	
								$response['status']=$status;
								$response['status_message']=$status_message;
								$json_response = json_encode($response);
								echo $json_response;
							}
						}
					}else{
						basic_fun();
						$status=200;
						$status_message="Please Select JPG, JPEG, PNG, MP4";
						header("HTTP/1.1 ".$status);	
						$response['status']=$status;
						$response['status_message']=$status_message;
						$json_response = json_encode($response);
						echo $json_response;
					}
				}else{
					
					basic_fun();
					$status=200;
					$status_message="Please Select JPG, JPEG, PNG, MP4";
					header("HTTP/1.1 ".$status);	
					$response['status']=$status;
					$response['status_message']=$status_message;
					$json_response = json_encode($response);
					echo $json_response;
				}
			}else{
				
				basic_fun();
				$status=200;
				$status_message="Please select small size file";
				header("HTTP/1.1 ".$status);	
				$response['status']=$status;
				$response['status_message']=$status_message;
				$json_response = json_encode($response);
				echo $json_response;
			}
		}else{
			
			basic_fun();
			$status=200;
			$status_message="Please Select Video or Image";
			header("HTTP/1.1 ".$status);	
			$response['status']=$status;
			$response['status_message']=$status_message;
			$json_response = json_encode($response);
			echo $json_response;
		}
    
?>