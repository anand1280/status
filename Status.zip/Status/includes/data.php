<?php
function mysqli_result($res,$row=0,$col=0){ 
    $numrows = mysqli_num_rows($res); 
    if ($numrows && $row <= ($numrows-1) && $row >=0){
        mysqli_data_seek($res,$row);
        $resrow = (is_numeric($col)) ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
        if (isset($resrow[$col])){
            return $resrow[$col];
        }
    }
    return false;
}

function qSELECT($query, $object = NULL){
	global $link;
	$result = mysqli_query($link, $query);
	$return = [];
	if($result){
		$num = mysqli_num_rows($result);
		for ($i=0; $i<$num; $i++){
			if(!is_null($object)){
				$row = mysqli_fetch_object($result);
			}else{
				$row = mysqli_fetch_array($result);
			}
			$return[$i]=$row;
		}
	}
	return $return;
}

function counting($table, $what){
	global $link;
	$query = "SELECT COUNT(1) FROM ".$table;
	$result = mysqli_query($link, $query);
	$num = mysqli_result($result, 0, 0);
	return $num;
}

function getById($table, $id){
	$query = "SELECT * FROM ".$table." WHERE id=".$id." ";
	$result = qSELECT($query);
	if($result) return $result[0];
	else return $result;
}

function getAll($table){
	$query = "SELECT * FROM ".$table;
	$result = qSELECT($query);
	return $result;
}

function queryToSelect($table, $where, $operator, $zerovalue, $key, $value, $id){
	$ul = '<option value="'.$zerovalue.'">Please select</option>';

	$query = "SELECT * FROM ".$table." WHERE `".$where."` ".$operator." ".$zerovalue." ";
	$result = qSELECT($query);
	foreach ($result as $row){
		$ul .= '<option value="'.$row[$key].'" ';
		$ul .= $id == $row[$key] ? "selected" : "" ;
		$ul .= '>'.$row[$value].'</option>';
	}
	return $ul;
}
function getPost(){
	
	$query="SELECT * FROM categorytbl as p ,languagetbl as c where p.languageid=c.languageid ORDER BY categoryid DESC";
	$result = qSELECT($query);
	return $result;
}

function getPost1(){
	
	$query="SELECT * FROM categorytbl as c ,languagetbl as l,posttbl as p where p.languageid=l.languageid AND p.categoryid=c.categoryid  ORDER BY p.categoryid DESC";
	$result = qSELECT($query);
	return $result;
}

function getPost2(){
	
	$query="SELECT * FROM categorytbl as c ,languagetbl as l,posttbl_img as p where p.languageid=l.languageid AND p.categoryid=c.categoryid  ORDER BY p.categoryid DESC";
	$result = qSELECT($query);
	return $result;
}
function getPost3(){
	
	$query="SELECT * FROM categorytbl as c ,languagetbl as l,posttbl_vertical as p where p.languageid=l.languageid AND p.categoryid=c.categoryid  ORDER BY p.categoryid DESC";
	$result = qSELECT($query);
	return $result;
}
function getPost4(){
	
	$query="SELECT * FROM posttbl_user";
	$result = qSELECT($query);
	return $result;
}
?>