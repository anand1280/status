<?php
				include "includes/header.php";
				?>

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <style>
                .btn {
                  background-color: DodgerBlue;
                  border: none;
                  color: white;
                  padding: 12px 30px;
                  cursor: pointer;
                  font-size: 20px;
                }
                .btn:hover {
                background-color: RoyalBlue;
                }
                </style>

				<h1>Post</h1>
				<p>This table includes <?php echo counting("posttbl_user", "id");?> posts.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Post Number</th>
					<th>Email</th>
					<th >Post name</th>
					<th>Download It!</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$i=1;
				$posttbl = getPost4();
				if($posttbl) foreach ($posttbl as $posttbls):
					?>
					<tr>
						<!--<td><?php echo $posttbls['postid']?></td>-->
						<td><?php echo $i; $i++; ?></td>
						<td><?php echo $posttbls['email']?></td>
						<td><?php echo $posttbls['postpath']?></td>
						
						<td><a  href="<?php echo $posttbls['postpath']?>" class="btn" target="_blank"><i class="fa fa-download"></i> Download</a></td>
						<td><a href="save.php?act=delete&id=<?php echo $posttbls['postid']?>&cat=posttbl_user" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				