<?php
include('../Database/db_connect.php');

function basic_fun(){
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    header("Content-Type:application/json");
}

if(isset($_GET['email']) && isset($_GET['password'])){
    if($_GET['email']!=null && $_GET['password']!=null){

        $uemail=$_GET['email'];
        $upassword=$_GET['password'];
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT * FROM user_infotbl WHERE uemail='$uemail' AND upassword=md5('$upassword')";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $set="Login ";
            }
            if(isset($set)){
                basic_fun();
                $status=200;
                $status_message="Login successfully";	
                header("HTTP/1.1 ".$status);	
                $response['status']=$status;
                $response['status_message']=$status_message;
                $json_response = json_encode($response);
                echo $json_response;
            }else{
                basic_fun();
                $status=400;
                $status_message="Something went wrong!1";	
                header("HTTP/1.1 ".$status);	
                $response['status']=$status;
                $response['status_message']=$status_message;
                $json_response = json_encode($response);
                echo $json_response;
            }
        } else {
            basic_fun();
            $status=400;
            $status_message="First register your-self";	
            header("HTTP/1.1 ".$status);	
            $response['status']=$status;
            $response['status_message']=$status_message;
            $json_response = json_encode($response);
            echo $json_response;
        }
        $conn->close();
    }
    else{
        basic_fun();
        $status=500;
        $status_message="Please fill out all details";	
        header("HTTP/1.1 ".$status);	
        $response['status']=$status;
        $response['status_message']=$status_message;
        $json_response = json_encode($response);
        echo $json_response;
    }
}else{
    basic_fun();
	$status=400;
	$status_message="Something went wrong!";	
	header("HTTP/1.1 ".$status);	
	$response['status']=$status;
	$response['status_message']=$status_message;
	$json_response = json_encode($response);
	echo $json_response;
}

?>