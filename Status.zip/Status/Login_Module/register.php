
<?php

include('../Database/db_connect.php');

function basic_fun(){
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		header("Access-Control-Allow-Methods: POST");
		header("Access-Control-Max-Age: 3600");
		header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
		header("Content-Type:application/json");
}
if(file_get_contents('php://input'))	
{
	$url=file_get_contents('php://input');
	$data = json_decode($url, true);
	
	if($data['email']!=null && $data['name']!=null && $data['password']!=null)
	{
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$uname=$data['name'];
	$uemail=$data['email'];
	$upassword=md5($data['password']);

	$sql = "SELECT * FROM user_infotbl WHERE uemail='$uemail'";
	$result = $conn->query($sql);

	if ($result->num_rows > 1) {
		basic_fun();
		$status=404;
		$status_message="You are already our member!!!";	
		header("HTTP/1.1 ".$status);	
		$response['status']=$status;
		$response['status_message']=$status_message;
		$json_response = json_encode($response);
		echo $json_response;
	}else{
		$sql = "INSERT INTO user_infotbl (uname,uemail,upassword,umobile) VALUES ('$uname','$uemail','$upassword','1010101010')";

	if ($conn->query($sql) === TRUE) {
			
			basic_fun();
			// the message
			$otp=rand(10000,99999);
			$msg = "Welcome to MYSTATUS application \n Your OTP is :"+$otp;

			// send email
			mail("$uemail","MyStatus Application OTP",$msg);
    		$status=200;
			$status_message="Registration completed successfully";	
			header("HTTP/1.1 ".$status);	
			$response['status']=$status;
			$response['status_message']=$status_message;
			$response['otp']=$otp;
			$json_response = json_encode($response);
			echo $json_response;
	} else {
			basic_fun();
    		$status=404;
			$status_message="Registration failed";	
			header("HTTP/1.1 ".$status);	
			$response['status']=$status;
			$response['status_message']=$status_message;
			$json_response = json_encode($response);
			echo $json_response;
	}

	$conn->close();
	}
	
}
else{
	basic_fun();
	$status=404;
	$status_message="Please fill out all details";	
	header("HTTP/1.1 ".$status);	
	$response['status']=$status;
	$response['status_message']=$status_message;
	$json_response = json_encode($response);
	echo $json_response;
}	
}else{
	basic_fun();
	$status=404;
	$status_message="Something went wrong!";	
	header("HTTP/1.1 ".$status);	
	$response['status']=$status;
	$response['status_message']=$status_message;
	$json_response = json_encode($response);
	echo $json_response;
}			

?>

