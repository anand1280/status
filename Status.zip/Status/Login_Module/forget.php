<?php
include('../Database/db_connect.php');

function basic_fun(){
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    header("Content-Type:application/json");
}

if(isset($_GET['email'])){
    if($_GET['email']!=null){

        $uemail=$_GET['email'];
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT * FROM user_infotbl WHERE uemail='$uemail'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $set="valid user";
            }
            if(isset($set)){
                $msg="
                    <html>
                        <head>
                        <title>Forget Password</title>
                    </head>
                        <body>
                            <h3> Here you need set new password of your MYSTATUS account </h3><br>
                            Click on below link.<br>
                            <a href='http://www.appforstatus.com/final_backup-master/API-MyStatus-Application/Final-API/Login_Module/setpassword.php?email=$uemail' >Set new password</a>
                        </body>
                    </html>
                            ";
                            $headers = "MIME-Version: 1.0" . "\r\n";
                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                mail("$uemail","Forget Password",$msg,$headers);
                basic_fun();
                $status=200;
                $status_message="We sent you a mail for geting your password";	
                header("HTTP/1.1 ".$status);	
                $response['status']=$status;
                $response['status_message']=$status_message;
                $json_response = json_encode($response);
                echo $json_response;
            }else{
                basic_fun();
                $status=400;
                $status_message="Something went wrong!1";	
                header("HTTP/1.1 ".$status);	
                $response['status']=$status;
                $response['status_message']=$status_message;
                $json_response = json_encode($response);
                echo $json_response;
            }
        } else {
            basic_fun();
            $status=400;
            $status_message="First register your-self";	
            header("HTTP/1.1 ".$status);	
            $response['status']=$status;
            $response['status_message']=$status_message;
            $json_response = json_encode($response);
            echo $json_response;
        }
        $conn->close();
    }
    else{
        basic_fun();
        $status=500;
        $status_message="Please fill out all details";	
        header("HTTP/1.1 ".$status);	
        $response['status']=$status;
        $response['status_message']=$status_message;
        $json_response = json_encode($response);
        echo $json_response;
    }
}else{
    basic_fun();
	$status=400;
	$status_message="Something went wrong!";	
	header("HTTP/1.1 ".$status);	
	$response['status']=$status;
	$response['status_message']=$status_message;
	$json_response = json_encode($response);
	echo $json_response;
}

?>