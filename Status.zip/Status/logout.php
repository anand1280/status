<?php
	setcookie("adminname","");
	setcookie("adminpass","");
	setcookie("auth","");
	header("location:"."index.php");
?>
