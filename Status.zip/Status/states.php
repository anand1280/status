<?php
$connection = mysqli_connect("localhost", "root", "anand1280");
if(!$connection){
	die("Database Connection Failed" . mysqli_error($connection));
}
$selectdb = mysqli_select_db($connection, 'status');
if(!$selectdb){
	die("Database Selection Failed" . mysqli_error($connection));
}
$country_id = (int) $_GET['country_id'];
$sql = "SELECT * FROM categorytbl WHERE languageid=$country_id";
$result = mysqli_query($connection, $sql);
    
	echo "<option disabled selected>Please Select Category</option>";

    foreach ($result as $row){
	echo "<option value='" . $row['categoryid'] . "'>" . $row['categoryname'] ."</option>";
}
 
?>